package com.naiwa.kwaifilter;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;

/** Pure rule engine. Interaction thresholds are opt-in; absent values never trigger a match. */
public final class RuleEngine {
    private RuleEngine() {}
    public static boolean blocked(JSONObject item, JSONObject config) {
        if (item == null || config == null || !config.optBoolean("enabled", true)) return false;
        String title = item.optString("title", "");
        String desc = item.optString("description", "");
        String author = item.optString("author", "");
        String authorId = item.optString("authorId", "");
        String tags = item.optString("tags", "");
        String comments = item.optString("comments", "");
        String haystack = (title + " " + desc + " " + tags).toLowerCase(Locale.ROOT);
        if (containsAny(haystack, config.optJSONArray("keywords"))) return true;
        if (containsAny((author + " " + authorId).toLowerCase(Locale.ROOT), config.optJSONArray("users"))) return true;
        if (containsAny(tags.toLowerCase(Locale.ROOT), config.optJSONArray("topics"))) return true;
        if (config.optBoolean("filterCommentText", false) && containsAny(comments.toLowerCase(Locale.ROOT), config.optJSONArray("commentKeywords"))) return true;
        if (config.has("minLikes") && item.has("likes") && item.optLong("likes") < config.optLong("minLikes")) return true;
        if (config.has("maxLikes") && item.has("likes") && item.optLong("likes") > config.optLong("maxLikes")) return true;
        if (config.has("minComments") && item.has("commentCount") && item.optLong("commentCount") < config.optLong("minComments")) return true;
        return config.has("maxComments") && item.has("commentCount") && item.optLong("commentCount") > config.optLong("maxComments");
    }
    private static boolean containsAny(String text, JSONArray rules) {
        if (rules == null) return false;
        for (int i=0;i<rules.length();i++) {
            String rule = rules.optString(i, "").trim().toLowerCase(Locale.ROOT);
            if (!rule.isEmpty() && text.contains(rule)) return true;
        }
        return false;
    }
}
