package com.naiwa.kwaifilter;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int IMPORT=10, EXPORT=11;
    private EditText keywords, topics, users, commentWords;
    private CheckBox enabled, commentFilter;
    private SharedPreferences prefs;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b); prefs=getSharedPreferences("kwai_filter", MODE_PRIVATE);
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(24,24,24,24);
        ScrollView scroll=new ScrollView(this); LinearLayout body=new LinearLayout(this); body.setOrientation(1); scroll.addView(body);
        enabled=new CheckBox(this); enabled.setText("启用过滤"); enabled.setChecked(prefs.getBoolean("enabled",true)); body.addView(enabled);
        keywords=field(body,"关键词（每行一个）","keywords"); topics=field(body,"话题/标签（每行一个）","topics"); users=field(body,"作者昵称或用户ID（每行一个）","users"); commentWords=field(body,"评论关键词（每行一个）","commentKeywords");
        commentFilter=new CheckBox(this); commentFilter.setText("启用评论文本过滤（需目标版本提供评论数据）"); commentFilter.setChecked(prefs.getBoolean("filterCommentText",false)); body.addView(commentFilter);
        Button save=new Button(this); save.setText("保存配置"); save.setOnClickListener(v->save()); body.addView(save);
        Button imp=new Button(this); imp.setText("导入配置"); imp.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,IMPORT);});body.addView(imp);
        Button exp=new Button(this); exp.setText("导出配置"); exp.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"kwai-filter-config.json");startActivityForResult(i,EXPORT);});body.addView(exp);
        TextView note=new TextView(this);note.setText("注意：当前版本是源码验证骨架。过滤规则引擎与配置导入导出已实现；快手 14.10.10.51087 的实际视频列表 Hook 点尚未确认，因此不会伪装成已生效的过滤模块。");body.addView(note);
        root.addView(scroll);setContentView(root);load();
    }
    private EditText field(LinearLayout p,String label,String key){TextView t=new TextView(this);t.setText(label);p.addView(t);EditText e=new EditText(this);e.setMinLines(2);e.setGravity(48);p.addView(e);e.setTag(key);return e;}
    private void load(){keywords.setText(prefs.getString("keywords",""));topics.setText(prefs.getString("topics",""));users.setText(prefs.getString("users",""));commentWords.setText(prefs.getString("commentKeywords",""));}
    private void save(){prefs.edit().putBoolean("enabled",enabled.isChecked()).putBoolean("filterCommentText",commentFilter.isChecked()).putString("keywords",keywords.getText().toString()).putString("topics",topics.getText().toString()).putString("users",users.getText().toString()).putString("commentKeywords",commentWords.getText().toString()).apply();Toast.makeText(this,"已保存。重启快手后重新加载配置。",0).show();}
    private JSONObject config() throws Exception {JSONObject j=new JSONObject();j.put("schemaVersion",1);j.put("enabled",enabled.isChecked());j.put("filterCommentText",commentFilter.isChecked());j.put("keywords",array(keywords));j.put("topics",array(topics));j.put("users",array(users));j.put("commentKeywords",array(commentWords));return j;}
    private JSONArray array(EditText e){JSONArray a=new JSONArray();for(String s:e.getText().toString().split("\\R")){s=s.trim();if(!s.isEmpty())a.put(s);}return a;}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(c!=RESULT_OK||d==null)return;try{if(r==EXPORT){try(OutputStream o=getContentResolver().openOutputStream(d.getData())){o.write(config().toString(2).getBytes(StandardCharsets.UTF_8));}}else if(r==IMPORT){try(InputStream in=getContentResolver().openInputStream(d.getData())){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[4096];int n;while((n=in.read(b))>0)out.write(b,0,n);JSONObject j=new JSONObject(out.toString("UTF-8"));enabled.setChecked(j.optBoolean("enabled",true));commentFilter.setChecked(j.optBoolean("filterCommentText",false));keywords.setText(lines(j.optJSONArray("keywords")));topics.setText(lines(j.optJSONArray("topics")));users.setText(lines(j.optJSONArray("users")));commentWords.setText(lines(j.optJSONArray("commentKeywords")));save();}}}catch(Exception e){Toast.makeText(this,"配置处理失败："+e.getMessage(),1).show();}}
    private String lines(JSONArray a){if(a==null)return "";StringBuilder s=new StringBuilder();for(int i=0;i<a.length();i++){if(i>0)s.append('\n');s.append(a.optString(i));}return s.toString();}
}
