package com.naiwa.kwaifilter;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import android.content.SharedPreferences;
import org.json.JSONObject;
import org.json.JSONArray;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;

/**
 * Initial compatibility adapter for Kwai 14.10.10.51087.
 * The exact feed-list owner/method must be confirmed against runtime traces before enabling destructive list edits.
 */
public final class KwaiHook implements IXposedHookLoadPackage {
    private static final String TARGET = "com.smile.gifmaker";
    private static final String PREFS = "kwai_filter";
    @Override public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET.equals(lpparam.packageName)) return;
        XposedBridge.log("KwaiFilter: loaded " + lpparam.packageName + " " + lpparam.processName);
        // Diagnostic-only hook: records likely feed model classes without modifying playback or server responses.
        String[] models = {"com.kuaishou.android.model.feed.VideoFeed", "com.kwai.framework.model.feed.BaseFeed"};
        for (String name : models) {
            try {
                Class<?> c = XposedHelpers.findClassIfExists(name, lpparam.classLoader);
                if (c == null) continue;
                XposedBridge.log("KwaiFilter: model found " + name);
                for (Method m : c.getDeclaredMethods()) {
                    if (m.getParameterTypes().length == 0 && m.getReturnType() == String.class) {
                        m.setAccessible(true);
                        XposedBridge.hookMethod(m, new XC_MethodHook() {
                            @Override protected void afterHookedMethod(MethodHookParam p) {
                                // Metadata probe only; do not log user content.
                            }
                        });
                    }
                }
            } catch (Throwable t) { XposedBridge.log("KwaiFilter model probe: " + t); }
        }
        XposedBridge.log("KwaiFilter: safe probe active; feed adapter awaits verified method mapping");
    }
}
